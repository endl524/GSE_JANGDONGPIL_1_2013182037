#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>

#include <iostream>
#include <vector>
#include <Windows.h>
#include <mmsystem.h>
#include <random>

using namespace std;

#define WINDOWSIZE_WIDTH 500
#define WINDOWSIZE_HEIGHT 800